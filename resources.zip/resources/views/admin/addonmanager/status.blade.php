<label class="switch">
  <input {{ $coupan->status == 1 ? "checked" : "" }} type="checkbox"
      class="quizfp toggle-input toggle-buttons" name="status">
    <span class="knob"></span>
    