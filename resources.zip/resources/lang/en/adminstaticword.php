<?php

return array (
  'Language' => '',
  'SelectCourse' => '',
);
