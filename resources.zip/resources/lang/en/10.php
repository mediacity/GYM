<?php

return array (
  '00am' => '',
  '00pm' => '',
);
