<?php

return array (
  'CannotDeleteDefaultLanguage' => '',
);
